# 📚 لوحة تحكم المعلم - أ. خليل البلوشي

<div align="center">

![Next.js](https://img.shields.io/badge/Next.js-16-black?style=for-the-badge&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue?style=for-the-badge&logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4-38B2AC?style=for-the-badge&logo=tailwind-css)
![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)

**لوحة تحكم متكاملة للمعلمين لإدارة الملاحظات والاستفسارات**

[🚀 مميزات المشروع](#-مميزات-المشروع) • [📦 التثبيت](#-التثبيت) • [⚙️ الإعداد](#️-الإعداد) • [🤝 المساهمة](#-المساهمة)

</div>

---

## 📖 نظرة عامة

نظام متكامل لإدارة الملاحظات والاستفسارات بين المعلم وأولياء الأمور، مصمم خصيصاً للأستاذ خليل البلوشي - معلم اللغة العربية للصف الخامس في مدرسة سعد بن معاذ بسلطنة عُمان.

---

## 🚀 مميزات المشروع

### 🎨 تصميم عصري
- واجهة مستخدم عصرية وجذابة باستخدام **Tailwind CSS** و **shadcn/ui**
- دعم كامل للغة العربية (**RTL**)
- تصميم متجاوب يعمل على جميع الأجهزة
- انتقالات سلسة وحركات جميلة

### ⚡ أداء عالي
- **Next.js 16** مع App Router
- **React 19** للمكونات
- تخزين محلي للعمل بدون اتصال
- تحميل هيكلي (Skeleton) أثناء جلب البيانات

### 🔧 وظائف متكاملة
- 📌 إدارة الملاحظات (واجبات، أنشطة، تنبيهات)
- 💬 نظام استفسارات أولياء الأمور
- 🖼️ رفع الصور مع الضغط التلقائي
- 🔐 نظام تسجيل دخول آمن
- 📊 إحصائيات وملخصات

---

## 🛠️ التقنيات المستخدمة

| التقنية | الاستخدام |
|---------|----------|
| ![Next.js](https://img.shields.io/badge/Next.js-16-black) | إطار العمل الرئيسي |
| ![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue) | لغة البرمجة |
| ![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4-38B2AC) | التصميم |
| ![shadcn/ui](https://img.shields.io/badge/shadcn/ui-000000) | مكونات UI |
| ![Framer Motion](https://img.shields.io/badge/Framer_Motion-11-FF0055) | الحركات والانتقالات |
| ![Lucide Icons](https://img.shields.io/badge/Lucide_Icons-000000) | الأيقونات |

---

## 📦 التثبيت

### المتطلبات
- Node.js 18+
- npm أو yarn أو bun

### الخطوات

```bash
# استنساخ المشروع
git clone https://github.com/your-username/teacher-dashboard.git

# الدخول للمجلد
cd teacher-dashboard

# تثبيت التبعيات
npm install
# أو
yarn install
# أو
bun install

# تشغيل الخادم التطويري
npm run dev
# أو
yarn dev
# أو
bun dev
```

افتح [http://localhost:3000](http://localhost:3000) في المتصفح.

---

## ⚙️ الإعداد

### 1. إعداد Google Apps Script

يستخدم المشروع Google Apps Script كـ Backend. تأكد من:
- نشر الـ Script كـ Web App
- تفعيل الوصول للجميع
- تحديث رابط API في `src/app/api/dashboard/route.ts`

### 2. هيكل البيانات المتوقع

```typescript
interface DashboardData {
  notices: Notice[];      // قائمة الملاحظات
  queries: Query[];       // قائمة الاستفسارات
  nId: number;           // آخر ID للملاحظات
  qId: number;           // آخر ID للاستفسارات
  settings?: {
    password: string;    // كلمة المرور
  };
}
```

### 3. متغيرات البيئة (اختياري)

أنشئ ملف `.env.local`:

```env
# كلمة المرور الافتراضية
DEFAULT_PASSWORD=your_password
```

---

## 📁 هيكل المشروع

```
teacher-dashboard/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   └── dashboard/
│   │   │       └── route.ts      # API للتواصل مع Google Script
│   │   ├── globals.css           # الأنماط العامة
│   │   ├── layout.tsx            # تخطيط الصفحة
│   │   └── page.tsx              # الصفحة الرئيسية
│   ├── components/
│   │   └── ui/                   # مكونات shadcn/ui
│   ├── hooks/
│   │   ├── use-toast.ts          # Toast notifications
│   │   └── use-mobile.ts         # كشف الجهاز
│   ├── lib/
│   │   ├── utils.ts              # دوال مساعدة
│   │   └── db.ts                 # قاعدة البيانات
│   └── types/
│       └── dashboard.ts          # أنواع TypeScript
├── public/
├── package.json
├── tailwind.config.ts
└── tsconfig.json
```

---

## 🎯 الاستخدام

### تسجيل الدخول
- كلمة المرور الافتراضية: `aysha123`
- يمكن تغييرها من الإعدادات داخل اللوحة

### إضافة ملاحظة
1. اضغط على "إضافة ملاحظة"
2. اختر النوع (واجب، نشاط، تنبيه)
3. اختر الشعبة
4. اكتب العنوان والتفاصيل
5. أرفق صورة (اختياري)
6. اضغط "حفظ ونشر"

### الرد على الاستفسارات
1. اذهب لقسم الاستفسارات
2. اضغط "إضافة رد"
3. اكتب الرد
4. اضغط "إرسال الرد"

---

## 🌐 النشر

### Vercel (موصى به)

```bash
# تثبيت Vercel CLI
npm i -g vercel

# النشر
vercel
```

### المنصات الأخرى
- Netlify
- Railway
- Render
- أي منصة تدعم Next.js

---

## 🤝 المساهمة

المساهمات مرحب بها! يرجى:

1. Fork المشروع
2. إنشاء فرع جديد (`git checkout -b feature/AmazingFeature`)
3. عمل Commit (`git commit -m 'Add some AmazingFeature'`)
4. Push للفرع (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

---

## 📝 الترخيص

هذا المشروع مرخص تحت رخصة MIT - راجع ملف [LICENSE](LICENSE) للتفاصيل.

---

## 📞 التواصل

<div align="center">

**أ. خليل البلوشي**

🏫 مدرسة سعد بن معاذ - شمال الباطنة - سلطنة عُمان

</div>

---

<div align="center">

**⭐ إذا أعجبك المشروع، لا تنسَ إعطاؤه نجمة! ⭐**

[![Star History Chart](https://api.star-history.com/svg?repos=your-username/teacher-dashboard&type=Date)](https://star-history.com/#your-username/teacher-dashboard&Date)

</div>
