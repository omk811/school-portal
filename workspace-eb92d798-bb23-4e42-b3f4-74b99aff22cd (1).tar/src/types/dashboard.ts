// أنواع البيانات للوحة تحكم المعلم

export type NoticeType = 'homework' | 'activity' | 'alert';
export type QueryStatus = 'new' | 'read' | 'replied';
export type ClassType = 'all' | '5A' | '5B' | '5C';

export interface Notice {
  id: number;
  type: NoticeType;
  cls: string;
  title: string;
  det?: string;
  date: string;
  img?: string;
}

export interface Query {
  id: number;
  name: string;
  student?: string;
  cls: string;
  msg: string;
  date: string;
  status: QueryStatus;
  reply?: string;
}

export interface Settings {
  password: string;
}

export interface DashboardData {
  notices: Notice[];
  queries: Query[];
  nId: number;
  qId: number;
  settings?: Settings;
}

export interface ApiResponse {
  status: 'success' | 'error';
  data?: DashboardData;
  message?: string;
}

// أسماء الشعب
export const CLASS_NAMES: Record<string, string> = {
  all: 'جميع الشعب',
  '5A': 'الخامس 1',
  '5B': 'الخامس 2',
  '5C': 'الخامس 3'
};

// أسماء أنواع الملاحظات
export const NOTICE_TYPE_NAMES: Record<NoticeType, string> = {
  homework: 'واجب 📝',
  activity: 'نشاط 🎯',
  alert: 'تنبيه 🔔'
};

// ألوان الأنواع
export const NOTICE_TYPE_COLORS: Record<NoticeType, { bg: string; text: string; border: string }> = {
  homework: { bg: 'bg-blue-100', text: 'text-blue-700', border: 'border-r-blue-500' },
  activity: { bg: 'bg-emerald-100', text: 'text-emerald-700', border: 'border-r-emerald-500' },
  alert: { bg: 'bg-amber-100', text: 'text-amber-700', border: 'border-r-amber-500' }
};
