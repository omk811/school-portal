import { NextRequest, NextResponse } from 'next/server';
import { ApiResponse } from '@/types/dashboard';

const API_URL = 'https://script.google.com/macros/s/AKfycbxao2vzL5tPFhirn-Bb98Dx9XobBJEH0M89Dzsma2aqvshgzSL4dx6ebPhSgR8WO-WoRQ/exec';

// جلب البيانات من Google Script
export async function GET() {
  try {
    const response = await fetch(`${API_URL}?action=loadData&t=${Date.now()}`, {
      cache: 'no-store',
    });
    const json: ApiResponse = await response.json();
    
    if (json.status === 'success' && json.data) {
      return NextResponse.json({ status: 'success', data: json.data });
    }
    
    return NextResponse.json({ status: 'error', message: 'فشل في جلب البيانات' }, { status: 500 });
  } catch (error) {
    console.error('Error fetching data:', error);
    return NextResponse.json({ status: 'error', message: 'خطأ في الاتصال' }, { status: 500 });
  }
}

// إرسال البيانات إلى Google Script
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, ...data } = body;

    const formData = new URLSearchParams();
    formData.append('action', action);
    
    Object.entries(data).forEach(([key, value]) => {
      if (typeof value === 'object') {
        formData.append(key, JSON.stringify(value));
      } else {
        formData.append(key, String(value));
      }
    });

    const response = await fetch(API_URL, {
      method: 'POST',
      body: formData,
    });
    
    const json = await response.json();
    return NextResponse.json(json);
  } catch (error) {
    console.error('Error posting data:', error);
    return NextResponse.json({ status: 'error', message: 'خطأ في الإرسال' }, { status: 500 });
  }
}
