'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOpen, MessageSquare, CheckCircle, Bell, Plus, RefreshCw, Home, LogOut,
  GraduationCap, Calendar, Clock, Trash2, Send, X, Eye, EyeOff, ChevronDown,
  FileText, Target, AlertTriangle, User, Settings as SettingsIcon, Key
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { DashboardData, Notice, Query, NoticeType, CLASS_NAMES, NOTICE_TYPE_NAMES, NOTICE_TYPE_COLORS } from '@/types/dashboard';

// ═══════════════════════════════════════════════════════════════
// الثوابت والتكوين
// ═══════════════════════════════════════════════════════════════
const STORAGE_KEY = 'school_data_v2';
const PWD_KEY = 'teacher_pwd';
const DEFAULT_PASSWORD = 'aysha123';

// ═══════════════════════════════════════════════════════════════
// Hook مخصص للإشعارات
// ═══════════════════════════════════════════════════════════════
function useToast() {
  const [toast, setToast] = useState<{ msg: string; type: 'ok' | 'err' | 'warn' } | null>(null);

  const showToast = useCallback((msg: string, type: 'ok' | 'err' | 'warn' = 'ok') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3200);
  }, []);

  return { toast, showToast };
}

// ═══════════════════════════════════════════════════════════════
// مكون الشاشة التحميل
// ═══════════════════════════════════════════════════════════════
function LoadingBar({ isLoading }: { isLoading: boolean }) {
  return (
    <motion.div
      initial={{ scaleX: 0, opacity: 0 }}
      animate={{
        scaleX: isLoading ? [0.3, 0.7, 0.3] : 0,
        opacity: isLoading ? 1 : 0
      }}
      transition={{ duration: 1.2, repeat: isLoading ? Infinity : 0 }}
      className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-400 via-amber-500 to-blue-500 z-[9999] origin-right"
    />
  );
}

// ═══════════════════════════════════════════════════════════════
// مكون Toast
// ═══════════════════════════════════════════════════════════════
function ToastNotification({ toast }: { toast: { msg: string; type: 'ok' | 'err' | 'warn' } | null }) {
  return (
    <AnimatePresence>
      {toast && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className={cn(
            'fixed bottom-6 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full font-bold shadow-2xl z-[1000]',
            'text-white',
            toast.type === 'ok' && 'bg-emerald-500',
            toast.type === 'err' && 'bg-rose-500',
            toast.type === 'warn' && 'bg-amber-500 text-slate-900'
          )}
        >
          {toast.msg}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ═══════════════════════════════════════════════════════════════
// مكون شاشة تسجيل الدخول
// ═══════════════════════════════════════════════════════════════
function LoginScreen({
  onLogin,
  isLoading,
  error
}: {
  onLogin: (password: string) => void;
  isLoading: boolean;
  error: string | null;
}) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(password);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-800 via-blue-800 to-blue-600 relative overflow-hidden">
      {/* الخلفية المتحركة */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
          className="absolute -top-1/2 -left-1/2 w-full h-full opacity-5"
        >
          <div className="w-full h-full bg-gradient-to-br from-amber-400 to-transparent rounded-full blur-3xl" />
        </motion.div>
      </div>

      {/* النص الخلفي */}
      <div className="absolute text-[15vw] font-bold text-white/5 font-sans pointer-events-none select-none">
        المحبرة
      </div>

      {/* بطاقة الدخول */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full max-w-md"
      >
        <Card className="border-0 shadow-2xl bg-white/95 backdrop-blur-xl">
          <CardContent className="pt-8 pb-8 px-8">
            {/* الشعار */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
              className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-500 flex items-center justify-center shadow-lg shadow-amber-500/30"
            >
              <Key className="w-10 h-10 text-white" />
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-center mb-8"
            >
              <h1 className="text-2xl font-bold text-slate-800 font-cairo">لوحة تحكم المعلم</h1>
              <p className="text-slate-500 mt-2 text-sm">
                الأستاذ خليل البلوشي<br />
                اللغة العربية · الصف الخامس
              </p>
            </motion.div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-700 font-bold text-sm">كلمة المرور</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="text-center text-xl tracking-[0.3em] h-12 bg-slate-50 border-2 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10"
                    dir="ltr"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                disabled={isLoading || !password}
                className="w-full h-12 text-lg font-bold bg-gradient-to-r from-slate-800 to-slate-700 hover:from-slate-700 hover:to-slate-600 shadow-lg shadow-slate-500/25 transition-all duration-300 hover:-translate-y-0.5"
              >
                {isLoading ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  >
                    <RefreshCw className="w-5 h-5" />
                  </motion.div>
                ) : (
                  'دخول اللوحة'
                )}
              </Button>

              <AnimatePresence>
                {error && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="p-3 rounded-lg bg-rose-50 text-rose-600 text-center font-bold text-sm"
                  >
                    ⚠️ {error}
                  </motion.div>
                )}
              </AnimatePresence>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// مكون الهيدر
// ═══════════════════════════════════════════════════════════════
function Header({
  currentDate,
  onRefresh,
  onLogout,
  isRefreshing,
  selectedClass,
  onClassChange,
  notices,
  className
}: {
  currentDate: string;
  onRefresh: () => void;
  onLogout: () => void;
  isRefreshing: boolean;
  selectedClass: string;
  onClassChange: (cls: string) => void;
  notices: Notice[];
  className?: string;
}) {
  const getClassCount = (cls: string) => {
    if (cls === 'all') return notices.length;
    return notices.filter(n => n.cls === cls || n.cls === 'all').length;
  };

  return (
    <header className={cn('sticky top-0 z-50 shadow-xl', className)}>
      <div className="bg-gradient-to-r from-slate-800 via-blue-800 to-blue-600">
        <div className="max-w-7xl mx-auto px-4">
          {/* الشريط العلوي */}
          <div className="flex items-center justify-between py-4 border-b border-white/10 gap-4 flex-wrap">
            <div className="flex items-center gap-4">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="w-14 h-14 rounded-xl bg-gradient-to-br from-amber-400 to-amber-500 flex items-center justify-center shadow-lg shadow-amber-500/30"
              >
                <BookOpen className="w-7 h-7 text-white" />
              </motion.div>
              <div>
                <h1 className="text-xl font-bold text-white">لوحة تحكم المعلم</h1>
                <p className="text-sm text-white/70">أ. خليل البلوشي · اللغة العربية · الصف الخامس</p>
              </div>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <div className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-lg bg-black/20 text-white/80 text-sm">
                <Calendar className="w-4 h-4" />
                <span>{currentDate}</span>
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={onRefresh}
                disabled={isRefreshing}
                className="bg-amber-500/20 border border-amber-400/30 text-amber-100 hover:bg-amber-500/30"
              >
                {isRefreshing ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  >
                    <RefreshCw className="w-4 h-4" />
                  </motion.div>
                ) : (
                  <RefreshCw className="w-4 h-4" />
                )}
                <span className="hidden sm:inline">تحديث</span>
              </Button>

              <Button
                variant="ghost"
                size="sm"
                className="bg-amber-500/20 border border-amber-400/30 text-amber-100 hover:bg-amber-500/30"
                asChild
              >
                <a href="/">
                  <Home className="w-4 h-4" />
                  <span className="hidden sm:inline">الرئيسية</span>
                </a>
              </Button>

              <Button
                variant="ghost"
                size="sm"
                onClick={onLogout}
                className="bg-white/10 border border-white/20 text-white hover:bg-white/20"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">خروج</span>
              </Button>
            </div>
          </div>

          {/* شريط التبويبات */}
          <div className="flex items-center gap-2 py-3 overflow-x-auto scrollbar-hide">
            {['all', '5A', '5B', '5C'].map((cls) => (
              <motion.button
                key={cls}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onClassChange(cls)}
                className={cn(
                  'flex items-center gap-2 px-5 py-2.5 rounded-lg font-bold text-sm transition-all whitespace-nowrap',
                  selectedClass === cls
                    ? 'bg-amber-400 text-slate-800 shadow-lg shadow-amber-500/30'
                    : 'bg-white/10 text-white/70 hover:bg-white/15 hover:text-white border border-white/10'
                )}
              >
                {cls === 'all' ? (
                  <>
                    <FileText className="w-4 h-4" />
                    جميع الشعب
                  </>
                ) : (
                  <>
                    {CLASS_NAMES[cls]}
                    <span className={cn(
                      'px-2 py-0.5 rounded-full text-xs',
                      selectedClass === cls ? 'bg-slate-800/20 text-slate-800' : 'bg-slate-800 text-amber-300'
                    )}>
                      {getClassCount(cls)}
                    </span>
                  </>
                )}
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}

// ═══════════════════════════════════════════════════════════════
// مكون بطاقات الإحصائيات
// ═══════════════════════════════════════════════════════════════
function StatsCards({ data }: { data: DashboardData | null }) {
  const stats = useMemo(() => {
    if (!data) return { notices: 0, queries: 0, replied: 0, newQueries: 0 };
    return {
      notices: data.notices.length,
      queries: data.queries.length,
      replied: data.queries.filter(q => q.status === 'replied').length,
      newQueries: data.queries.filter(q => q.status === 'new').length,
    };
  }, [data]);

  const cards = [
    { label: 'إجمالي الملاحظات', value: stats.notices, icon: FileText, color: 'from-blue-500 to-blue-600', bg: 'bg-blue-100', iconColor: 'text-blue-600' },
    { label: 'الاستفسارات', value: stats.queries, icon: MessageSquare, color: 'from-amber-500 to-amber-600', bg: 'bg-amber-100', iconColor: 'text-amber-600' },
    { label: 'تمت الإجابة', value: stats.replied, icon: CheckCircle, color: 'from-emerald-500 to-emerald-600', bg: 'bg-emerald-100', iconColor: 'text-emerald-600' },
    { label: 'استفسار جديد', value: stats.newQueries, icon: Bell, color: 'from-rose-500 to-rose-600', bg: 'bg-rose-100', iconColor: 'text-rose-600' },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {cards.map((card, i) => (
        <motion.div
          key={card.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          whileHover={{ y: -4, transition: { duration: 0.2 } }}
        >
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
            <CardContent className="p-5">
              <div className="flex items-center gap-4">
                <div className={cn('w-14 h-14 rounded-xl flex items-center justify-center', card.bg)}>
                  <card.icon className={cn('w-7 h-7', card.iconColor)} />
                </div>
                <div>
                  <div className="text-3xl font-black text-slate-800">{card.value}</div>
                  <div className="text-sm text-slate-500 font-medium">{card.label}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// مكون عنصر الملاحظة
// ═══════════════════════════════════════════════════════════════
function NoticeItem({
  notice,
  onDelete,
  index
}: {
  notice: Notice;
  onDelete: (id: number) => void;
  index: number;
}) {
  const colors = NOTICE_TYPE_COLORS[notice.type];

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ x: -4 }}
      className={cn(
        'relative bg-slate-50 rounded-xl p-5 border-2 border-slate-200 hover:shadow-lg transition-all duration-300',
        colors.border, 'border-r-4'
      )}
    >
      <button
        onClick={() => onDelete(notice.id)}
        className="absolute top-4 left-4 w-8 h-8 rounded-full bg-white border-2 border-slate-200 flex items-center justify-center text-slate-400 hover:bg-rose-500 hover:border-rose-500 hover:text-white transition-colors"
      >
        <X className="w-4 h-4" />
      </button>

      <div className="flex items-center justify-between mb-3 gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <Badge className={cn(colors.bg, colors.text, 'font-bold')}>
            {NOTICE_TYPE_NAMES[notice.type]}
          </Badge>
          <Badge variant="outline" className="bg-slate-100 text-slate-600 font-bold">
            {CLASS_NAMES[notice.cls] || notice.cls}
          </Badge>
        </div>
        <span className="text-sm text-slate-500">{notice.date}</span>
      </div>

      <h3 className="text-lg font-bold text-slate-800 mb-2">{notice.title}</h3>
      {notice.det && (
        <p className="text-slate-600 leading-relaxed whitespace-pre-wrap">{makeLinks(notice.det)}</p>
      )}
      {notice.img && (
        <img
          src={notice.img}
          alt="مرفق"
          className="w-full max-h-72 object-cover rounded-lg mt-4 border-2 border-slate-200"
          loading="lazy"
        />
      )}
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════
// مكون عنصر الاستفسار
// ═══════════════════════════════════════════════════════════════
function QueryItem({
  query,
  onReply,
  onDelete,
  index
}: {
  query: Query;
  onReply: (id: number, reply: string) => void;
  onDelete: (id: number) => void;
  index: number;
}) {
  const [showReply, setShowReply] = useState(false);
  const [replyText, setReplyText] = useState(query.reply || '');

  const statusColors = {
    new: { border: 'border-r-rose-500', badge: 'bg-rose-100 text-rose-600', label: '🔴 جديد' },
    read: { border: 'border-r-slate-400', badge: 'bg-slate-100 text-slate-600', label: '👁 مقروء' },
    replied: { border: 'border-r-emerald-500', badge: 'bg-emerald-100 text-emerald-600', label: '✅ تم الرد' },
  };

  const status = statusColors[query.status];

  const handleSubmitReply = () => {
    if (!replyText.trim()) return;
    onReply(query.id, replyText.trim());
    setShowReply(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ delay: index * 0.05 }}
      className={cn(
        'bg-slate-50 rounded-xl p-5 border-2 border-slate-200 hover:shadow-lg transition-all duration-300',
        status.border, 'border-r-4'
      )}
    >
      <div className="flex items-start justify-between mb-4 gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 font-bold text-slate-800">
            <User className="w-5 h-5" />
            {query.name || 'ولي أمر'}
          </div>
          <div className="text-sm text-slate-500 mt-1">
            الطالب: {query.student || '—'} · {CLASS_NAMES[query.cls] || query.cls} · {query.date}
          </div>
        </div>
        <Badge className={cn(status.badge, 'font-bold')}>{status.label}</Badge>
      </div>

      <div className="bg-white border-2 border-slate-200 rounded-lg p-4 mb-4 text-slate-600 leading-relaxed whitespace-pre-wrap">
        {makeLinks(query.msg)}
      </div>

      {query.reply && (
        <div className="bg-emerald-50 border-2 border-emerald-200 rounded-lg p-4 mb-4">
          <div className="text-sm font-bold text-emerald-600 mb-2">✅ ردك الحالي:</div>
          <p className="text-emerald-800 leading-relaxed whitespace-pre-wrap">{makeLinks(query.reply)}</p>
        </div>
      )}

      <Separator className="my-4" />

      <div className="flex items-center gap-3 flex-wrap">
        <Button
          variant="default"
          size="sm"
          onClick={() => setShowReply(!showReply)}
          className="bg-slate-800 hover:bg-slate-700"
        >
          <MessageSquare className="w-4 h-4" />
          {query.reply ? 'تعديل الرد' : 'إضافة رد'}
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onDelete(query.id)}
          className="bg-rose-50 text-rose-600 hover:bg-rose-100 border border-rose-200"
        >
          <Trash2 className="w-4 h-4" />
          حذف
        </Button>
      </div>

      <AnimatePresence>
        {showReply && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-4 bg-white border-2 border-slate-200 rounded-lg p-4">
              <Textarea
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="اكتب ردك هنا..."
                className="min-h-24 bg-slate-50 border-2 focus:border-blue-500"
              />
              <Button
                onClick={handleSubmitReply}
                disabled={!replyText.trim()}
                className="mt-3 bg-emerald-500 hover:bg-emerald-600"
              >
                <Send className="w-4 h-4" />
                إرسال الرد
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════
// مكون إضافة ملاحظة
// ═══════════════════════════════════════════════════════════════
function AddNoticeDialog({
  open,
  onOpenChange,
  onAdd
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (notice: Omit<Notice, 'id' | 'date'>) => void;
}) {
  const [type, setType] = useState<NoticeType>('homework');
  const [cls, setCls] = useState('all');
  const [title, setTitle] = useState('');
  const [details, setDetails] = useState('');
  const [image, setImage] = useState('');
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingImage(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX = 600;
        let w = img.width;
        let h = img.height;
        if (w > MAX) {
          h = Math.round((h * MAX) / w);
          w = MAX;
        }
        canvas.width = w;
        canvas.height = h;
        canvas.getContext('2d')?.drawImage(img, 0, 0, w, h);
        setImage(canvas.toDataURL('image/jpeg', 0.6));
        setIsProcessingImage(false);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    if (!title.trim()) return;
    setIsSaving(true);
    onAdd({ type, cls, title: title.trim(), det: details.trim() || undefined, img: image || undefined });
    // إعادة تعيين الحقول
    setType('homework');
    setCls('all');
    setTitle('');
    setDetails('');
    setImage('');
    setIsSaving(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">📝 إضافة ملاحظة جديدة</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="font-bold">نوع الملاحظة</Label>
              <Select value={type} onValueChange={(v) => setType(v as NoticeType)}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="homework">📝 واجب</SelectItem>
                  <SelectItem value="activity">🎯 نشاط</SelectItem>
                  <SelectItem value="alert">🔔 تنبيه</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="font-bold">الشعبة</Label>
              <Select value={cls} onValueChange={setCls}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الشعب</SelectItem>
                  <SelectItem value="5A">الخامس 1</SelectItem>
                  <SelectItem value="5B">الخامس 2</SelectItem>
                  <SelectItem value="5C">الخامس 3</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="font-bold">عنوان الملاحظة</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: واجب درس الفاعل صفحة 25"
              className="bg-slate-50 border-2"
            />
          </div>

          <div className="space-y-2">
            <Label className="font-bold">التفاصيل (اختياري)</Label>
            <Textarea
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              placeholder="تفاصيل إضافية، روابط، توضيحات..."
              className="min-h-24 bg-slate-50 border-2"
            />
          </div>

          <div className="space-y-2">
            <Label className="font-bold">إرفاق صورة (اختياري)</Label>
            <Input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="bg-slate-50 border-2 cursor-pointer"
            />
            {isProcessingImage && (
              <div className="flex items-center gap-2 text-slate-500 py-4">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                >
                  <RefreshCw className="w-4 h-4" />
                </motion.div>
                جاري معالجة الصورة...
              </div>
            )}
            {image && !isProcessingImage && (
              <img src={image} alt="معاينة" className="max-h-48 rounded-lg border-2 border-slate-200" />
            )}
          </div>

          <Button
            onClick={handleSave}
            disabled={!title.trim() || isSaving}
            className="w-full h-12 text-lg font-bold bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700"
          >
            {isSaving ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
              >
                <RefreshCw className="w-5 h-5" />
              </motion.div>
            ) : (
              <>
                <CheckCircle className="w-5 h-5" />
                حفظ ونشر الملاحظة
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ═══════════════════════════════════════════════════════════════
// مكون ملخص الشعب
// ═══════════════════════════════════════════════════════════════
function ClassStats({ data }: { data: DashboardData | null }) {
  const stats = useMemo(() => {
    if (!data) return [];
    return ['5A', '5B', '5C'].map((cls) => ({
      cls,
      name: CLASS_NAMES[cls],
      notices: data.notices.filter(n => n.cls === cls || n.cls === 'all').length,
      queries: data.queries.filter(q => q.cls === cls).length,
    }));
  }, [data]);

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-lg">
          <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
            <GraduationCap className="w-5 h-5 text-blue-600" />
          </div>
          ملخص الشعب
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {stats.map((stat) => (
          <div
            key={stat.cls}
            className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border-2 border-slate-200 hover:bg-white hover:shadow-md transition-all"
          >
            <span className="font-bold text-slate-700">{stat.name}</span>
            <div className="flex items-center gap-2">
              <Badge className="bg-blue-100 text-blue-700 font-bold">
                📌 {stat.notices}
              </Badge>
              <Badge className="bg-amber-100 text-amber-700 font-bold">
                💬 {stat.queries}
              </Badge>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

// ═══════════════════════════════════════════════════════════════
// مكون الإعدادات
// ═══════════════════════════════════════════════════════════════
function SettingsCard({
  onChangePassword,
  showToast
}: {
  onChangePassword: (password: string) => void;
  showToast: (msg: string, type: 'ok' | 'err' | 'warn') => void;
}) {
  const [pwd1, setPwd1] = useState('');
  const [pwd2, setPwd2] = useState('');

  const handleSave = () => {
    if (!pwd1) {
      showToast('⚠️ أدخل كلمة المرور الجديدة', 'warn');
      return;
    }
    if (pwd1 !== pwd2) {
      showToast('⚠️ كلمتا المرور غير متطابقتين', 'warn');
      return;
    }
    onChangePassword(pwd1);
    setPwd1('');
    setPwd2('');
    showToast('✅ تم تغيير كلمة المرور', 'ok');
  };

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-lg">
          <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center">
            <SettingsIcon className="w-5 h-5 text-slate-600" />
          </div>
          الإعدادات
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-xl border-2 border-slate-200 mb-4">
          <div className="text-3xl">🏫</div>
          <div>
            <div className="font-bold text-slate-800">مدرسة سعد بن معاذ</div>
            <div className="text-sm text-slate-500">شمال الباطنة · سلطنة عُمان</div>
          </div>
        </div>

        <Separator className="my-4" />

        <div className="space-y-4">
          <div className="text-sm font-bold text-slate-600 flex items-center gap-2">
            <Key className="w-4 h-4" />
            تغيير كلمة المرور
          </div>

          <div className="space-y-3">
            <div className="space-y-2">
              <Label className="text-sm">كلمة المرور الجديدة</Label>
              <Input
                type="password"
                value={pwd1}
                onChange={(e) => setPwd1(e.target.value)}
                placeholder="••••••••"
                className="bg-slate-50 border-2"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm">تأكيد كلمة المرور</Label>
              <Input
                type="password"
                value={pwd2}
                onChange={(e) => setPwd2(e.target.value)}
                placeholder="••••••••"
                className="bg-slate-50 border-2"
              />
            </div>
            <Button
              onClick={handleSave}
              className="w-full bg-gradient-to-r from-slate-700 to-slate-800 hover:from-slate-800 hover:to-slate-900"
            >
              <Key className="w-4 h-4" />
              حفظ التغييرات
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ═══════════════════════════════════════════════════════════════
// دالة تحويل الروابط
// ═══════════════════════════════════════════════════════════════
function makeLinks(text: string): React.ReactNode {
  if (!text) return '';
  const parts = text.split(/(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/gi);
  return parts.map((part, i) => {
    if (/^(https?:\/\/|www\.|@)/i.test(part)) {
      const href = part.includes('@') ? `mailto:${part}` : part.startsWith('www') ? `http://${part}` : part;
      return (
        <a
          key={i}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-500 hover:text-blue-700 underline decoration-dotted underline-offset-2"
        >
          {part}
        </a>
      );
    }
    return part;
  });
}

// ═══════════════════════════════════════════════════════════════
// مكون التحميل الهيكلي
// ═══════════════════════════════════════════════════════════════
function SkeletonLoader() {
  return (
    <div className="space-y-4">
      {[1, 2, 3].map((i) => (
        <div key={i} className="bg-slate-50 rounded-xl p-5 border-2 border-slate-200">
          <div className="flex items-center gap-2 mb-4">
            <Skeleton className="h-6 w-20 rounded-full" />
            <Skeleton className="h-6 w-24 rounded-full" />
          </div>
          <Skeleton className="h-6 w-3/4 mb-3" />
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-2/3" />
        </div>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// المكون الرئيسي
// ═══════════════════════════════════════════════════════════════
export default function TeacherDashboard() {
  // الحالات
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [data, setData] = useState<DashboardData | null>(null);
  const [selectedClass, setSelectedClass] = useState('all');
  const [noticeFilter, setNoticeFilter] = useState<'all' | NoticeType>('all');
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [currentDate, setCurrentDate] = useState('');

  const { toast, showToast } = useToast();

  // تحديث التاريخ
  useEffect(() => {
    const updateDate = () => {
      const now = new Date();
      setCurrentDate(
        now.toLocaleDateString('ar-OM', { weekday: 'short', month: 'short', day: 'numeric' }) +
        ' | ' +
        now.toLocaleTimeString('ar-OM', { hour: '2-digit', minute: '2-digit' })
      );
    };
    updateDate();
    const interval = setInterval(updateDate, 60000);
    return () => clearInterval(interval);
  }, []);

  // جلب البيانات
  const fetchData = useCallback(async (showLoading = true) => {
    if (showLoading) setIsLoading(true);
    try {
      const response = await fetch('/api/dashboard');
      const json = await response.json();
      if (json.status === 'success' && json.data) {
        setData(json.data);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(json.data));
      } else {
        // استخدام الكاش المحلي
        const cached = localStorage.getItem(STORAGE_KEY);
        if (cached) {
          setData(JSON.parse(cached));
          showToast('⚠️ يعمل بنسخة محفوظة — تحقق من الاتصال', 'warn');
        }
      }
    } catch (error) {
      const cached = localStorage.getItem(STORAGE_KEY);
      if (cached) {
        setData(JSON.parse(cached));
        showToast('⚠️ يعمل بنسخة محفوظة — تحقق من الاتصال', 'warn');
      }
    } finally {
      if (showLoading) setIsLoading(false);
    }
  }, [showToast]);

  // تسجيل الدخول
  const handleLogin = useCallback(async (password: string) => {
    setIsLoading(true);
    setLoginError(null);

    try {
      const response = await fetch('/api/dashboard');
      const json = await response.json();
      const storedPassword = json.data?.settings?.password || localStorage.getItem(PWD_KEY) || DEFAULT_PASSWORD;

      if (password === storedPassword) {
        if (json.data) {
          setData(json.data);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(json.data));
        }
        setIsLoggedIn(true);
      } else {
        setLoginError('كلمة المرور غير صحيحة');
        setTimeout(() => setLoginError(null), 3000);
      }
    } catch {
      setLoginError('خطأ في الاتصال');
    } finally {
      setIsLoading(false);
    }
  }, []);

  // تسجيل الخروج
  const handleLogout = useCallback(() => {
    setIsLoggedIn(false);
    setData(null);
  }, []);

  // التحديث اليدوي
  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await fetchData(false);
    setIsRefreshing(false);
    showToast('✅ تم تحديث البيانات', 'ok');
  }, [fetchData, showToast]);

  // تصفية الملاحظات
  const filteredNotices = useMemo(() => {
    if (!data?.notices) return [];
    return data.notices.filter((n) => {
      const classMatch = selectedClass === 'all' || n.cls === 'all' || n.cls === selectedClass;
      const typeMatch = noticeFilter === 'all' || n.type === noticeFilter;
      return classMatch && typeMatch;
    });
  }, [data?.notices, selectedClass, noticeFilter]);

  // تصفية الاستفسارات
  const filteredQueries = useMemo(() => {
    if (!data?.queries) return [];
    return data.queries
      .filter((q) => selectedClass === 'all' || q.cls === selectedClass)
      .sort((a, b) => (a.status === 'new' ? -1 : 1));
  }, [data?.queries, selectedClass]);

  // إضافة ملاحظة
  const handleAddNotice = useCallback(async (notice: Omit<Notice, 'id' | 'date'>) => {
    if (!data) return;

    const now = new Date();
    const newNotice: Notice = {
      ...notice,
      id: ++data.nId,
      date: now.toLocaleDateString('ar-OM') + ' ' + now.toLocaleTimeString('ar-OM', { hour: '2-digit', minute: '2-digit' }),
    };

    const newData = { ...data, notices: [newNotice, ...data.notices], nId: data.nId };
    setData(newData);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
    showToast('✅ تمت الإضافة بنجاح', 'ok');

    // إرسال للسيرفر في الخلفية
    fetch('/api/dashboard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'saveNotices', data: newData.notices }),
    }).catch(() => {});
  }, [data, showToast]);

  // حذف ملاحظة
  const handleDeleteNotice = useCallback(async (id: number) => {
    if (!data || !confirm('هل تريد حذف هذه الملاحظة؟')) return;

    const newData = {
      ...data,
      notices: data.notices.filter((n) => n.id !== id),
    };
    setData(newData);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
    showToast('🗑 تم الحذف', 'warn');

    fetch('/api/dashboard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'deleteNotice', id }),
    }).catch(() => {});
  }, [data, showToast]);

  // إرسال رد
  const handleReply = useCallback(async (id: number, reply: string) => {
    if (!data) return;

    const newQueries = data.queries.map((q) =>
      q.id === id ? { ...q, reply, status: 'replied' as const } : q
    );
    const newData = { ...data, queries: newQueries };
    setData(newData);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
    showToast('✅ تم إرسال الرد', 'ok');

    fetch('/api/dashboard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'updateQuery', id, status: 'replied', reply }),
    }).catch(() => {});
  }, [data, showToast]);

  // حذف استفسار
  const handleDeleteQuery = useCallback(async (id: number) => {
    if (!data || !confirm('هل تريد حذف هذا الاستفسار؟')) return;

    const newData = {
      ...data,
      queries: data.queries.filter((q) => q.id !== id),
    };
    setData(newData);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
    showToast('🗑 تم الحذف', 'warn');

    fetch('/api/dashboard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'deleteQuery', id }),
    }).catch(() => {});
  }, [data, showToast]);

  // تغيير كلمة المرور
  const handleChangePassword = useCallback((password: string) => {
    localStorage.setItem(PWD_KEY, password);
    if (data) {
      const newData = {
        ...data,
        settings: { ...(data.settings || {}), password },
      };
      setData(newData);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
    }
  }, [data]);

  // ═══════════════════════════════════════════════════════════════
  // العرض
  // ═══════════════════════════════════════════════════════════════
  if (!isLoggedIn) {
    return (
      <>
        <LoadingBar isLoading={isLoading} />
        <LoginScreen onLogin={handleLogin} isLoading={isLoading} error={loginError} />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-blue-50 to-slate-100" dir="rtl">
      <LoadingBar isLoading={isLoading || isRefreshing} />

      {/* الهيدر */}
      <Header
        currentDate={currentDate}
        onRefresh={handleRefresh}
        onLogout={handleLogout}
        isRefreshing={isRefreshing}
        selectedClass={selectedClass}
        onClassChange={setSelectedClass}
        notices={data?.notices || []}
      />

      {/* المحتوى الرئيسي */}
      <main className="max-w-7xl mx-auto px-4 py-6 pb-24">
        {/* بطاقات الإحصائيات */}
        <StatsCards data={data} />

        <div className="flex flex-col lg:flex-row gap-6">
          {/* المنطقة الرئيسية */}
          <div className="flex-1 space-y-6">
            {/* قسم الملاحظات */}
            <Card className="border-0 shadow-lg">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                      <FileText className="w-5 h-5 text-blue-600" />
                    </div>
                    إدارة الملاحظات والتنبيهات
                  </CardTitle>
                  <Button
                    onClick={() => setAddDialogOpen(true)}
                    className="bg-slate-800 hover:bg-slate-700"
                  >
                    <Plus className="w-4 h-4" />
                    إضافة ملاحظة
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {/* فلاتر الملاحظات */}
                <div className="flex items-center gap-2 mb-4 flex-wrap">
                  {[
                    { key: 'all', label: 'الكل' },
                    { key: 'homework', label: '📝 واجبات', icon: FileText },
                    { key: 'activity', label: '🎯 أنشطة', icon: Target },
                    { key: 'alert', label: '🔔 تنبيهات', icon: AlertTriangle },
                  ].map((filter) => (
                    <button
                      key={filter.key}
                      onClick={() => setNoticeFilter(filter.key as 'all' | NoticeType)}
                      className={cn(
                        'px-4 py-2 rounded-full font-bold text-sm transition-all',
                        noticeFilter === filter.key
                          ? 'bg-slate-800 text-white shadow-md'
                          : 'bg-white border-2 border-slate-200 text-slate-500 hover:border-blue-400 hover:text-blue-500'
                      )}
                    >
                      {filter.label}
                    </button>
                  ))}
                </div>

                {/* قائمة الملاحظات */}
                <div className="space-y-4">
                  {isLoading ? (
                    <SkeletonLoader />
                  ) : filteredNotices.length === 0 ? (
                    <div className="text-center py-16 text-slate-500">
                      <FileText className="w-16 h-16 mx-auto mb-4 opacity-30" />
                      <p className="font-bold">لا توجد ملاحظات في هذا القسم</p>
                    </div>
                  ) : (
                    <AnimatePresence mode="popLayout">
                      {filteredNotices.map((notice, i) => (
                        <NoticeItem
                          key={notice.id}
                          notice={notice}
                          onDelete={handleDeleteNotice}
                          index={i}
                        />
                      ))}
                    </AnimatePresence>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* قسم الاستفسارات */}
            <Card className="border-0 shadow-lg">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                    <MessageSquare className="w-5 h-5 text-amber-600" />
                  </div>
                  استفسارات أولياء الأمور
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {isLoading ? (
                    <SkeletonLoader />
                  ) : filteredQueries.length === 0 ? (
                    <div className="text-center py-16 text-slate-500">
                      <MessageSquare className="w-16 h-16 mx-auto mb-4 opacity-30" />
                      <p className="font-bold">لا توجد استفسارات حالياً</p>
                    </div>
                  ) : (
                    <AnimatePresence mode="popLayout">
                      {filteredQueries.map((query, i) => (
                        <QueryItem
                          key={query.id}
                          query={query}
                          onReply={handleReply}
                          onDelete={handleDeleteQuery}
                          index={i}
                        />
                      ))}
                    </AnimatePresence>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* الشريط الجانبي */}
          <aside className="w-full lg:w-80 space-y-6 lg:sticky lg:top-36 lg:self-start">
            <ClassStats data={data} />
            <SettingsCard onChangePassword={handleChangePassword} showToast={showToast} />
          </aside>
        </div>
      </main>

      {/* نافذة إضافة ملاحظة */}
      <AddNoticeDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        onAdd={handleAddNotice}
      />

      {/* الإشعارات */}
      <ToastNotification toast={toast} />
    </div>
  );
}
